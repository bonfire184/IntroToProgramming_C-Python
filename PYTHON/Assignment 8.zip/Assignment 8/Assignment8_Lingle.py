def CreateDictionary(filename):
	translation = {}
	
	File = open(filename, 'r')
	
	info = File.readlines()
	
	for line in info:
		line = line.strip()
		info = line.split(",")
		
		translation[info[0]] = info[1].strip()
	File.close()
	
	return translation
	
	
def main():
	
	translation = CreateDictionary("textToEnglish.txt")
	Input1 = "y"
	while Input1 != "quit":
	
		Input1 = raw_input("Keep searching for abbrevitations? y/quit: ")
		
		if Input1 == "y":
			
			
			input = raw_input("Type an abbreviation: ")
			
			#input.search(" ")
			t = input.split(" ")
			
			
			for x in t:
				if x in translation:
					print translation[x],
				else:
					print "NF",
			print ""
	
	

if __name__ == "__main__":
	main()
